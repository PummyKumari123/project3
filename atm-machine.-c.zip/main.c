/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <conio.h>
long amount=50000,deposit,withdraw;
int choice, pin, k;
char transction='y';
void main()
{

while( pin !=4424 )
{
    printf("enter your secret PIN:");
    scanf("%d",&pin);
    if( pin != 4424)
    printf("Please Enter Your Valid Password");
    do
{
    printf("************************WELCOME TO ATM MACHINE************************\n");
    printf("1. Check Balance\n");
    printf("2. Withdraw Cash\n");
    printf("3. Deposit Cash\n");
    printf("4. Quit\n");
    printf("************ATM SERVICE************");
    printf("Enter Your Choice ");
    scanf("%d",&choice);

    switch(choice)
    {
        case 1:
        printf("\n Your Balance in RS:%lu",amount);
        break;

        case 2:
        printf("\n Enter The Amount to Withdraw :");
        scanf("%lu",&withdraw);
        if(withdraw % 100 != 0)
        {
            printf("\n Please Enter The Amount in Multiple of 100");

        }
        else if(withdraw > (amount-5000))
        {
            printf("\n INSUFFICIENT BALANCE");
        }
        else{
            amount =amount-withdraw;
            printf("\n\n PLEASE COLLECT YOUR CASH");
            printf("\n YOUR CURRENT BALANCE IS :%lu",amount);
        }
        break;
        case 3:
        printf("\n Enter The Amount Of Deposit");
        scanf("%lu",&deposit);
        amount=amount+deposit;
        printf("Your CURRENT BALANCE is:%lu",amount);
        break;
         case 4:
         printf("\n THANKYOU FOR USING ATM MACHINE");
         break;
          default:
          printf("\n INVALID CHOICE");
    }
    printf("\n\n\n\n DO U WISH TO HAVE ANOTHER TRANSCTION? (Yes/No):\n");
    fflush(stdin);
    scanf("%c",&transction);

    if( transction =='n' || transction =='N');
    k=1;

}
while(!k);
printf("\n\n THANKS FOR USING OUR ATM MACHINE:");
}
getch();

}


    
